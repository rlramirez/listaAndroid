package com.example.ramiro.liststore;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AgregarLista extends Activity implements View.OnClickListener {
    EditText et,place, cantidad;
    Button btnAgregar, read_bt;
    SQLControlador dbconeccion;
    public String formatteDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_lista);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        et = (EditText) findViewById(R.id.nombre);
        place = (EditText) findViewById(R.id.lugar);
        cantidad = (EditText) findViewById(R.id.cantidad);
        btnAgregar = (Button) findViewById(R.id.btnAgregarId);
        read_bt = (Button) findViewById(R.id.btnListar);

        dbconeccion = new SQLControlador(this);
        try {
            dbconeccion.abrirBaseDeDatos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        btnAgregar.setOnClickListener(this);
        read_bt.setOnClickListener(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String name = et.getText().toString();
                //dbconeccion.insertarDatos(name,"fecha","loja");
                Intent main = new Intent(AgregarLista.this, MainActivity.class);
                startActivity(main);
            }
        });
    }

    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
            case R.id.btnAgregarId:
                String name = et.getText().toString();
                String lug = place.getText().toString();
                String cant = cantidad.getText().toString();
                String estado = "activo";

                //obtener la fecha del sisitema
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                formatteDate = sdf.format(new Date());

                //inserta en la base de datos de la app
                dbconeccion.insertarDatos(name,formatteDate,lug, cant, estado);
                //dbconeccion.insertarDatos("Prueba nombre","fecha","lugar", "2", "acti");
                Intent main = new Intent(this, AgregarLista.class);
                startActivity(main);
                break;
            case R.id.btnListar:
                Intent main1 = new Intent(this, MainActivity.class);
                startActivity(main1);
                break;

            default:
                break;
        }
    }


}
