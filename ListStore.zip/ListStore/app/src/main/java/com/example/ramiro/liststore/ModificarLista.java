package com.example.ramiro.liststore;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View.OnClickListener;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.sql.SQLException;

public class ModificarLista extends AppCompatActivity implements OnClickListener{
    EditText et, e_nombre,e_fecha, e_lugar, e_cantidad, e_estado;
    Button btnActualizar, btnEliminar;

    long member_id;
    SQLControlador dbcon;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_lista);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbcon = new SQLControlador(this);
        try {
            dbcon.abrirBaseDeDatos();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        et = (EditText) findViewById(R.id.et_miembro_id);
        //e_nombre = (EditText) findViewById(R.id.et_miembronombre);
        e_fecha = (EditText) findViewById(R.id.et_miembrofecha);
        e_lugar = (EditText) findViewById(R.id.et_miembrolugar);
        e_cantidad = (EditText) findViewById(R.id.et_miembrocantidad);
        e_estado = (EditText) findViewById(R.id.et_miembroestado);
        btnActualizar = (Button) findViewById(R.id.btnActualizar);
        btnEliminar = (Button) findViewById(R.id.btnEliminar);

        Intent i = getIntent();
        String memberID = i.getStringExtra("miembroId");
        String memberName = i.getStringExtra("miembroNombre");
        String memberFecha = i.getStringExtra("miembroFecha");
        String memberLugar = i.getStringExtra("miembroLugar");
        String memberCantidad = i.getStringExtra("miembroCantidad");
        String memberEstado = i.getStringExtra("miembroEstado");

        member_id = Long.parseLong(memberID);

        et.setText(memberName);
        e_fecha.setText(memberFecha);
        e_lugar.setText(memberLugar);
        e_cantidad.setText(memberCantidad);
        e_estado.setText(memberEstado);

        btnActualizar.setOnClickListener(this);
        btnEliminar.setOnClickListener(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
            case R.id.btnActualizar:
                String memName_upd = et.getText().toString();
                String memFecha = e_fecha.getText().toString();
                String memPlace = e_lugar.getText().toString();
                String memCant = e_cantidad.getText().toString();
                String memEsta = e_estado.getText().toString();
                dbcon.actualizarDatos(member_id, memName_upd,memFecha, memPlace, memCant, memEsta);
                this.returnHome();
                break;

            case R.id.btnEliminar:
                dbcon.deleteData(member_id);
                this.returnHome();
                break;
        }
    }

    public void returnHome() {

        Intent home_intent = new Intent(getApplicationContext(),
                MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        startActivity(home_intent);
    }

}
