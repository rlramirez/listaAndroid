package com.example.ramiro.liststore;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by ramiro on 15/12/15.
 */
class DBhelper extends SQLiteOpenHelper {

    // Información de la tabla
    public static final String TABLE_LISTA = "listas";
    public static final String LISTA_ID = "_id";
    public static final String LISTA_NOMBRE = "nombre";
    public static final String LISTA_FECHA = "fecha";
    public static final String LISTA_LUGAR = "lugar";
    public static final String LISTA_CANTIDAD = "cantidad";
    public static final String LISTA_ESTADO = "estado";

    // información del a base de datos
    static final String DB_NAME = "DBLISTSTORE";
    static final int DB_VERSION = 1;

    // Información de la base de datos
    private static final String CREATE_TABLE = "create table "
            + TABLE_LISTA + "(" + LISTA_ID
            + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + LISTA_NOMBRE + " TEXT NOT NULL ,"
            + LISTA_FECHA + " TEXT NOT NULL ,"
            + LISTA_LUGAR + " TEXT NOT NULL ,"
            + LISTA_CANTIDAD + " TEXT NOT NULL ,"
            + LISTA_ESTADO + " TEXT NOT NULL);";

    public DBhelper(Context context) {
        super(context, DB_NAME, null,DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LISTA);
        onCreate(db);
    }
}