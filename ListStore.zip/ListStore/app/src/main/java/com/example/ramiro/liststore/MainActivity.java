package com.example.ramiro.liststore;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {
    Button btnAgregarMiembro;
    ListView lista;
    SQLControlador dbconeccion;
    TextView tv_miemID, tv_miemNombre, tv_miemFecha, tv_miemLugar, tv_miemCantidad, tv_miemEstado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dbconeccion = new SQLControlador(this);
        try {
            dbconeccion.abrirBaseDeDatos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        lista = (ListView) findViewById(R.id.listViewListas);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent iagregar = new Intent(MainActivity.this, AgregarLista.class);
                startActivity(iagregar);

            }
        });

        // Tomar los datos desde la base de datos para poner en el curso y después en el adapter
        Cursor cursor = dbconeccion.leerDatos();

        String[] from = new String[] {
                DBhelper.LISTA_ID,
                DBhelper.LISTA_NOMBRE,
                DBhelper.LISTA_FECHA,
                DBhelper.LISTA_LUGAR,
                DBhelper.LISTA_CANTIDAD,
                DBhelper.LISTA_ESTADO
        };
        int[] to = new int[] {
                R.id.lista_id,
                R.id.lista_nombre,
                R.id.lista_fecha,
                R.id.lista_lugar,
                R.id.lista_cantidad,
                R.id.lista_estado
        };

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                MainActivity.this, R.layout.activity_formatofila, cursor, from, to);

        adapter.notifyDataSetChanged();
        lista.setAdapter(adapter);

        // acción cuando hacemos click en item para poder modificarlo o eliminarlo
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View view, int position, long id) {

                tv_miemID = (TextView) view.findViewById(R.id.lista_id);
                tv_miemNombre = (TextView) view.findViewById(R.id.lista_nombre);
                tv_miemFecha = (TextView) view.findViewById(R.id.lista_fecha);
                tv_miemLugar = (TextView) view.findViewById(R.id.lista_lugar);
                tv_miemCantidad = (TextView) view.findViewById(R.id.lista_cantidad);
                tv_miemEstado = (TextView) view.findViewById(R.id.lista_estado);

                String aux_miembroId = tv_miemID.getText().toString();
                String aux_miembroNombre = tv_miemNombre.getText().toString();
                String aux_miembroFecha = tv_miemFecha.getText().toString();
                String aux_miembroLugar = tv_miemLugar.getText().toString();
                String aux_miembroCantidad="", aux_miembroEstado="";
                try {
                    aux_miembroCantidad = tv_miemCantidad.getText().toString();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "No hay datos cantidad", Toast.LENGTH_SHORT).show();
                };
                try {
                    aux_miembroEstado = tv_miemEstado.getText().toString();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "No hay datos estado", Toast.LENGTH_SHORT).show();
                };

                Intent modify_intent = new Intent(getApplicationContext(), ModificarLista.class);
                modify_intent.putExtra("miembroId", aux_miembroId);
                modify_intent.putExtra("miembroNombre", aux_miembroNombre);
                modify_intent.putExtra("miembroFecha", aux_miembroFecha);
                modify_intent.putExtra("miembroLugar", aux_miembroLugar);
                modify_intent.putExtra("miembroCantidad", aux_miembroCantidad);
                modify_intent.putExtra("miembroEstado", aux_miembroEstado);
                startActivity(modify_intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
