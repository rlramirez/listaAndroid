package com.example.ramiro.liststore;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

/**
 * Created by ramiro on 15/12/15.
 */
public class SQLControlador {
    private DBhelper dbhelper;
    private Context ourcontext;
    private SQLiteDatabase database;

    public SQLControlador(Context c) {
        ourcontext = c;
    }

    public SQLControlador abrirBaseDeDatos() throws SQLException {
        dbhelper = new DBhelper(ourcontext);
        database = dbhelper.getWritableDatabase();
        return this;
    }

    public void cerrar() {
        dbhelper.close();
    }

    public void insertarDatos(String name,String fecha,String lugar, String cantidad, String estado) {
        ContentValues cv = new ContentValues();
        cv.put(DBhelper.LISTA_NOMBRE, name);
        cv.put(DBhelper.LISTA_FECHA, fecha);
        cv.put(DBhelper.LISTA_LUGAR, lugar);
        cv.put(DBhelper.LISTA_CANTIDAD, cantidad);
        cv.put(DBhelper.LISTA_ESTADO, estado);
        database.insert(DBhelper.TABLE_LISTA, null, cv);
    }

    public Cursor leerDatos() {
        String[] todasLasColumnas = new String[] {
                DBhelper.LISTA_ID,
                DBhelper.LISTA_NOMBRE,
                DBhelper.LISTA_FECHA,
                DBhelper.LISTA_LUGAR,
                DBhelper.LISTA_CANTIDAD,
                DBhelper.LISTA_ESTADO
        };
        Cursor c = database.query(DBhelper.TABLE_LISTA, todasLasColumnas, null,
                null, null, null, null, null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public int actualizarDatos(long memberID, String memberName, String memberDate, String memberPlace, String memberCantidad, String memberEstado) {
        ContentValues cvActualizar = new ContentValues();
        cvActualizar.put(DBhelper.LISTA_NOMBRE, memberName);
        cvActualizar.put(DBhelper.LISTA_FECHA, memberDate);
        cvActualizar.put(DBhelper.LISTA_LUGAR, memberPlace);
        cvActualizar.put(DBhelper.LISTA_CANTIDAD, memberCantidad);
        cvActualizar.put(DBhelper.LISTA_ESTADO, memberEstado);
        int i = database.update(DBhelper.TABLE_LISTA, cvActualizar,
                DBhelper.LISTA_ID + " = " + memberID, null);
        return i;
    }

    public void deleteData(long memberID) {
        database.delete(DBhelper.TABLE_LISTA, DBhelper.LISTA_ID + "="
                + memberID, null);
    }
}
